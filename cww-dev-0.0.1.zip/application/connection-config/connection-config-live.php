<?php
	
	$environment = "production";

	// define('BASE_URL', 'https://syllogicraft.000webhostapp.com/dev/');
	// define('BASE_URL', 'http://syllogicraft.heliohost.org/');
	define('BASE_URL', 'http://syllogicraft.epizy.com/cww/');

	define('DB_HOSTNAME', 'sql100.epizy.com');
	define('DB_USERNAME', 'epiz_21301143');
	define('DB_PASSWORD', 'syllogicraft99');
	define('DB_DATABASE', 'epiz_21301143_cww');
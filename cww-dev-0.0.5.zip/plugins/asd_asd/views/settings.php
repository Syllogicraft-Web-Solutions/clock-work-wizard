<?php if(isset($result)): ?>
    <p>
        <strong>Result:</strong> <?php echo $result; ?>
    </p>
    <hr />
<?php endif; ?>
<form action="" method="POST">
    <input name="name" value="John Doe" /><br />
    <input type="submit" />
</form>
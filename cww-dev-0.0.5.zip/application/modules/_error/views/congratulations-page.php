<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
?>


<section class="">
	
	<div class="hero-shot full-height full-width w3-display-container" style="">

		<div id="register-account" class="login-form w3-theme-l3 w3-display-middle w3-display-container">
			<div class="w3-container w3-theme">
				<h3>&nbsp;</i>Successfully signed up!</h3>
			</div>

			<div class="w3-padding w3-center">
				Make sure to check your email inbox for activation link.
				<a href="<?= base_url('login') ?>">Click here to login.</a>
			</div>
			
		</div>
	</div>
	
</section>
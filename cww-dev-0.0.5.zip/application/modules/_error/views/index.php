<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
?>

<div class="w3-container w3-padding">
	<h2>Employees</h2>
</div>
<section class="w3-container w3-padding">

	<a class="w3-button w3-theme-action w3-hover-theme" href="<?= base_url('_users/add_employee') ?>"><i class="fa fa-plus" aria-hidden="true"></i> Add Employee</a>



</section>
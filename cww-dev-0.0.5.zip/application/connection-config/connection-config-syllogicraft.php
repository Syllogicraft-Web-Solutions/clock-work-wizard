<?php
	
	$environment = "development";

     if (! $_SERVER['HTTP_HOST'] == 'localhost') {
          $url = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'];

          define('BASE_URL', $url);
          define('DB_HOSTNAME', 'sql303.epizy.com');
          define('DB_USERNAME', 'epiz_21585450');
          define('DB_PASSWORD', 'syllogicraft123');
          define('DB_DATABASE', 'epiz_21585450_cww');

          $email = array(
               'smtp_user' => 'registration@syllogicraft.epizy.com',
               'smtp_pass' => 'syllogicraft99',
               'mailtype' => 'html'
          );
          define('MAIL_SETTINGS', $email);
     } else {
          $url = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/cww/';

          define('BASE_URL', $url);
          // DB Settings here
          define('DB_HOSTNAME', 'localhost');
          define('DB_USERNAME', 'root');
          define('DB_PASSWORD', '');
          define('DB_DATABASE', 'cww');

          $email = array(
               'smtp_user' => 'registration@syllogicraft.epizy.com',
               'smtp_pass' => 'syllogicraft99',
               'mailtype' => 'html'
          );
          define('MAIL_SETTINGS', $email);
     }
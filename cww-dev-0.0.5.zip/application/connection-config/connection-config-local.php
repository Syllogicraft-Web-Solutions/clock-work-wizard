<?php
	
	$environment = "development";

	define('BASE_URL', 'http://localhost/cww/');

	// DB Settings here
	define('DB_HOSTNAME', 'localhost');
	define('DB_USERNAME', 'root');
	define('DB_PASSWORD', '');
	define('DB_DATABASE', 'cww');
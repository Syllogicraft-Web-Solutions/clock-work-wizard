<?php
     do_action('clocker.clock');
     do_action('clocker.display_buttons')
?>


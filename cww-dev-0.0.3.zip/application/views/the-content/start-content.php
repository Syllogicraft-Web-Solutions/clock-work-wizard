<?php
	
	if ($with_sidebar) {

?>
	<div id="the-content-with-sidebar" style="margin-left: <?= $options['width'] ?>">

<?php 

	} else {
?>

	<div>

<?php
	}
<?php
	
	$environment = "development";

	define('BASE_URL', 'syllogicraft.000webhostapp.com/cww/dev/');

	define('DB_HOSTNAME', 'localhost');
	define('DB_USERNAME', 'id4060368_syllogicraft_cww');
	define('DB_PASSWORD', 'syllogicraft12399');
	define('DB_DATABASE', 'id4060368_cww');
<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!-- <?= $script_name ?> -->
<script src="<?= $src ?>" <?= $type != '' ? "type='$type'" : '' ?> <?= $attrs ?>></script>
<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!-- <?= $link_name ?> -->
<link rel="<?= $rel ?>" type="<?= $type ?>" href="<?= $href ?>">
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Helloworld extends CI_Controller {

	function index() {
		echo "Hello World.";
	}

}
